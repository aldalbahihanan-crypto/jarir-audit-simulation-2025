# Jarir Audit Simulation 2025

An educational external-audit simulation for **Jarir Marketing Company (Jarir Bookstore)**. The project demonstrates audit planning, risk assessment, materiality, illustrative substantive testing, findings documentation, and executive reporting.

> **Important disclaimer:** This is an educational simulation, not an actual audit of Jarir Marketing Company. Public financial information is used only as context. All transaction-level revenue records, inventory items, identifiers, customer references, counts, and supporting evidence in the workbook are fictional and illustrative.

## Deliverables

- `Jarir_Audit_Simulation_2025.xlsx` — seven linked audit working-paper worksheets.
- `Jarir_Audit_Simulation_2025_Report.docx` — executive simulation report with sources, methodology, findings, recommendations, and limitations.
- `INTERVIEW_GUIDE_AR.md` — Arabic interview preparation guide explaining the decisions, calculations, and results.

## Workbook structure

| Worksheet | Purpose |
|---|---|
| `01_Audit_Planning` | Engagement scope, company understanding, analytical procedures, risks, and planned workpapers. |
| `02_Risk_Assessment` | Risk hypotheses, assertions, risk ratings, audit responses, and worksheet links. |
| `03_Materiality` | Benchmark selection, overall materiality, performance materiality, and clearly trivial threshold. |
| `04_Revenue_Testing` | Reported revenue context plus 12 fictional transactions tested for amount agreement, cut-off, and evidence. |
| `05_Inventory_Testing` | Reported inventory context plus 12 fictional items tested for quantity, value, condition, and obsolescence indicators. |
| `06_Audit_Findings` | Consolidated register of six illustrative findings and recommended follow-up actions. |
| `07_Audit_Summary` | Executive metrics, linked thresholds, conclusion, and recommendations. |

## Verified public financial context

Amounts are presented in **SAR '000** unless stated otherwise.

| Metric | 2025 | 2024 | Classification |
|---|---:|---:|---|
| Total revenue | 11,449,790 | 10,906,512 | Reported public financial information |
| Profit before zakat and income tax | 1,077,357 | 1,004,520 | Reported public financial information |
| Total assets | 4,416,028 | 4,272,694 | Reported public financial information |
| Total liabilities | 2,653,967 | 2,527,842 | Reported public financial information |
| Total equity | 1,762,061 | 1,744,852 | Reported public financial information |
| Net cash from operating activities | 1,457,666 | 1,113,808 | Reported public financial information |
| Gross inventories | 1,940,000 | 2,000,000 | Reported in audited financial statements / key audit matter |
| Slow-moving inventory provision | 228,000 | 208,000 | Reported in audited financial statements / key audit matter |

The 2025 Board of Directors Report also presents **sales of SAR 11,365.2 million**. The workbook deliberately distinguishes that sales measure from the Saudi Exchange total-revenue measure instead of combining them.

## Materiality methodology

The model selects profit before zakat and income tax as the benchmark because the entity is profitable and earnings are relevant to users. The percentages are explicit educational assumptions, not universal audit rules.

- Overall materiality = SAR 1,077,357 × 5.0% = **SAR 53,867.85 thousand**.
- Performance materiality = overall materiality × 75.0% = **SAR 40,400.89 thousand**.
- Clearly trivial threshold = overall materiality × 5.0% = **SAR 2,693.39 thousand**.

## Formula map

### Revenue testing

- Revenue growth: `=B5/B6-1`
- Transaction difference: `=I15-H15`
- Revenue result: an item is flagged when the supporting status is incomplete, the amount difference is non-zero, or the recognition year is not 2025.
- Summary counts use `COUNTA`, `COUNTIF`, and `SUM` over the sample table.

### Inventory testing

- Quantity difference: `=D17-E17`
- Recorded inventory value: `=D17*G17`
- Recalculated inventory value: `=E17*G17`
- Value difference: `=H17-I17`
- Inventory result: an item is flagged when there is a quantity difference, value difference, non-None obsolescence indicator, damage, or incomplete evidence.

### Materiality and cross-sheet links

- Overall materiality: `=B6*B14`
- Performance materiality: `=C13*B15`
- Clearly trivial threshold: `=C13*B16`
- Revenue and inventory workpapers reference `03_Materiality` instead of retyping thresholds.
- The summary references testing results and findings using cross-sheet formulas.

## Simulation results

- Revenue transactions tested: **12**.
- Revenue items without an identified exception: **9**.
- Revenue exceptions or follow-up items: **3**.
- Net illustrative revenue difference: **SAR (200) thousand**.
- Inventory items tested: **12**.
- Inventory items without an identified exception: **9**.
- Inventory exceptions or follow-up items: **3**.
- Illustrative inventory value difference: **SAR 450 thousand**.
- Findings register: **6 illustrative findings**.

These results are not projected to the full population and are not evidence of actual Jarir misstatements.

## Sources

1. [Jarir official company profile](https://www.jarir.com/sa-en/about-jarir) — company activities and business model.
2. [Saudi Exchange Jarir company profile](https://www.saudiexchange.sa/wps/portal/saudiexchange/hidden/company-profile-main/!ut/p/z1/04_Sj9CPykssy0xPLMnMz0vMAfIjo8ziTR3NDIw8LAz83d2MXA0C3SydAl1c3Q0NvE30I4EKzBEKDMKcTQzMDPxN3H19LAzdTU31w8syU8v1wwkpK8hOMgUA-oskdg!!/?companySymbol=4190) — financial summary and cash-flow figures.
3. [Jarir Board of Directors Report 2025](https://wps-media.jarir.com/wp-content/uploads/2026/04/JB_AnnualReport_2025_EN.pdf) — reported sales and operating context.
4. [Jarir audited consolidated financial statements for 2025](https://static.mubasher.info/File.Mix_Announcement_File/2B9C200F-6F8F-49EB-9D97-C3D541914ECD.pdf) — revenue recognition and inventory key-audit-matter context.

## How to upload this project to GitHub

### Option A — GitHub website

1. Sign in to GitHub and select **New repository**.
2. Name the repository `jarir-audit-simulation-2025`.
3. Select **Public** if this is a portfolio project and do not upload confidential information.
4. Add a short description such as: `Educational audit simulation for Jarir Marketing Company using linked Excel working papers and an executive report.`
5. Create the repository.
6. Select **Add file → Upload files**.
7. Upload the Excel workbook, Word report, this README, and `INTERVIEW_GUIDE_AR.md`.
8. Add the commit message `Add Jarir audit simulation working papers and report`.
9. Select **Commit changes**.

Do not upload the downloaded annual-report PDFs unless you have permission. The repository already contains official source links.

### Option B — Git command line

```bash
git clone https://github.com/YOUR-USERNAME/jarir-audit-simulation-2025.git
cd jarir-audit-simulation-2025

# Copy the three deliverables into this folder first.
git add README.md INTERVIEW_GUIDE_AR.md Jarir_Audit_Simulation_2025.xlsx Jarir_Audit_Simulation_2025_Report.docx
git commit -m "Add Jarir audit simulation working papers and report"
git push origin main
```

If GitHub asks for authentication, use the GitHub Desktop application or a Personal Access Token. Do not put passwords, tokens, private company records, or confidential client information in the repository.

## Suggested GitHub description

> Educational external-audit simulation for Jarir Marketing Company. Includes linked Excel audit working papers, materiality calculations, illustrative revenue and inventory testing, a findings register, and an executive report. Public financial data is sourced; transaction-level testing data is fictional and clearly labeled.
