# دليل المقابلة — Jarir Audit Simulation 2025

هذا الدليل يشرح كيف تدافعين عن المشروع بنفسك. احفظي المنطق، وليس الأرقام فقط.

## 1. ما هو المشروع؟

هذا **Educational External Audit Simulation**، وليس تدقيقًا حقيقيًا لجرير. استخدمت أرقامًا مالية عامة من مصادر منشورة لتكوين السياق المالي، ثم أنشأت معاملات إيرادات وأصناف مخزون خيالية لتوضيح طريقة تصميم اختبارات التدقيق.

الجملة المهمة في المقابلة:

> “I used verified public financial information for the planning context, while all transaction-level revenue and inventory records were clearly labeled as fictional and illustrative. Therefore, the project demonstrates audit methodology without claiming access to Jarir’s internal records.”

## 2. لماذا اخترت Revenue وInventory؟

اخترتهما لأن تقرير القوائم المالية المدققة لعام 2025 أشار إلى **Revenue recognition** و **Existence and valuation of inventories** كـ Key Audit Matters.

- الإيرادات مهمة لأنها تقيس أداء الشركة، وفيها مخاطر occurrence, accuracy, and cut-off.
- المخزون مهم بسبب تعدد المواقع، كثرة العمليات، ومخاطر quantity, valuation, obsolescence, and cut-off.

لا تقولي إن جرير لديها خطأ فعلي. قولي:

> “These were assessed as potential risks for planning purposes, not confirmed findings about Jarir.”

## 3. كيف تحققتِ من الأرقام؟

استخدمت ثلاث طبقات من التحقق:

1. **Saudi Exchange:** استخدمت منه total revenue, profit before zakat and income tax, total assets, liabilities, equity, and operating cash flow.
2. **Jarir Board of Directors Report 2025:** استخدمت منه sales metric والسياق التشغيلي.
3. **Audited consolidated financial statements:** استخدمت منها سياق revenue recognition والمخزون الإجمالي ومخصص slow-moving inventory.

الأرقام الأساسية:

- Revenue 2025: SAR 11,449,790 thousand.
- Revenue 2024: SAR 10,906,512 thousand.
- Profit before zakat and tax 2025: SAR 1,077,357 thousand.
- Gross inventory 2025: approximately SAR 1,940,000 thousand.
- Slow-moving provision 2025: SAR 228,000 thousand.

نقطة دفاع مهمة:

> “The Board Report presents sales of SAR 11,365.2 million, while the Saudi Exchange summary presents total revenue of SAR 11,449.790 million. I kept the measures separate because sales and total revenue are not automatically interchangeable.”

## 4. لماذا اخترت Profit Before Zakat and Tax للـ Materiality؟

لأن الشركة مربحة، والربحية مهمة لمستخدمي القوائم المالية. لم أختَر Revenue بشكل تلقائي لمجرد أنه أكبر رقم.

الصيغ:

- Overall materiality = Benchmark × 5.0%
- Performance materiality = Overall materiality × 75.0%
- Clearly trivial threshold = Overall materiality × 5.0%

النتائج:

- Overall materiality = SAR 53,867.85 thousand.
- Performance materiality = SAR 40,400.89 thousand.
- Clearly trivial threshold = SAR 2,693.39 thousand.

إذا سُئلتِ عن النسب:

> “The percentages are illustrative planning assumptions for this educational model, not universal audit requirements. I documented them explicitly so the reviewer can challenge or change them.”

## 5. كيف بنيتِ Revenue Testing؟

العينة تحتوي 12 معاملة خيالية. لم أقدّمها على أنها فواتير جرير حقيقية.

لكل معاملة قارنت:

- Invoice amount.
- Sales ledger amount.
- Fulfillment date.
- Revenue recognition date.
- Supporting evidence status.

الصيغ الأساسية:

- Difference = `Ledger amount – Invoice amount`.
- Revenue result flags an item if:
  - the support status is incomplete;
  - the amount difference is non-zero; or
  - the recognition year is not 2025.

النتائج:

- 12 transactions tested.
- 9 with no identified exception.
- 3 exception/follow-up items.
- Net illustrative difference = SAR (200) thousand.

لماذا يوجد cut-off exception؟

لأن إحدى العينات لها invoice date في 2025، لكن fulfillment and recognition date في 2026. تاريخ الفاتورة وحده لا يثبت صحة الاعتراف بالإيراد؛ يجب الرجوع إلى policy and transfer of control.

الجملة المقترحة:

> “I did not automatically treat the invoice date as the recognition date. I considered the fulfillment and recognition dates because cut-off depends on when control transfers under IFRS 15.”

## 6. كيف بنيتِ Inventory Testing؟

العينة تحتوي 12 صنفًا خياليًا. لكل صنف استخدمت:

- Recorded quantity.
- Illustrative count quantity.
- Unit cost.
- Recorded inventory value.
- Recalculated inventory value.
- Condition.
- Obsolescence indicator.
- Evidence status.

الصيغ:

- Quantity difference = `Recorded quantity – Count quantity`.
- Recorded value = `Recorded quantity × Unit cost`.
- Recalculated value = `Count quantity × Unit cost`.
- Value difference = `Recorded value – Recalculated value`.

الاختبار يرفع Exception إذا كان هناك:

- فرق كمية.
- فرق قيمة.
- مؤشر slow-moving أو obsolescence.
- حالة damaged.
- أدلة ناقصة.

النتائج:

- 12 items tested.
- 9 with no identified exception.
- 3 exception/follow-up items.
- Illustrative value difference = SAR 450 thousand.

لا تقولي إن هناك impairment فعلي. قولي:

> “The damaged and slow-moving items require further NRV and aging evidence. I did not conclude that an actual impairment exists.”

## 7. كيف بنيتِ Findings Register؟

كل finding يحتوي على:

- Procedure.
- Financial statement account.
- Condition.
- Criterion or policy.
- Potential impact.
- Materiality comparison.
- Risk implication.
- Recommended action.
- Status and conclusion.

عدد findings هو 6، لكنها **illustrative findings** وليست أخطاء مؤكدة في جرير.

الفرق الذي يجب شرحه:

- Missing documentation لا يعني تلقائيًا وجود misstatement.
- Potential misstatement ليس confirmed misstatement.
- Small sample لا يجوز extrapolate منه إلى كامل المجتمع دون منهج إسقاط صالح.
- Non-monetary evidence limitation قد يكون مهمًا حتى لو كان المبلغ غير معروف.

## 8. كيف تشرحين النتيجة العامة؟

النتيجة ليست “Qualified” أو “Unmodified opinion”. لا يوجد رأي تدقيق أصلًا.

النتيجة الصحيحة:

> “The simulation demonstrates a structured audit approach and identifies illustrative follow-up items. It does not support an audit opinion on Jarir’s actual financial statements because the transaction-level evidence and management access were not available.”

## 9. لماذا استخدمتِ Excel formulas بدل hardcoding؟

حتى يبقى النموذج live and reviewable. إذا تغير benchmark أو النسبة أو sample amount، تتغير النتائج تلقائيًا.

أمثلة:

- Materiality linked from `03_Materiality`.
- Revenue difference calculated from invoice and ledger amounts.
- Inventory values calculated from quantity and unit cost.
- Summary linked to testing sheets and findings register.

هذا يوضح auditability, traceability, and maintainability.

## 10. لماذا استخدمتِ سبع أوراق؟

لأنها تعكس audit workflow منطقي:

1. Planning.
2. Risk assessment.
3. Materiality.
4. Revenue testing.
5. Inventory testing.
6. Findings.
7. Summary.

كل ورقة لها غرض، ويوجد cross-reference بينها بدل وضع كل شيء في جدول واحد.

## 11. كيف ترفعين المشروع على GitHub؟

### الطريقة الأسهل من الموقع

1. افتحي GitHub وسجلي الدخول.
2. اضغطي **New repository**.
3. اكتبي الاسم: `jarir-audit-simulation-2025`.
4. اختاري Public إذا كان للمحفظة المهنية.
5. اضغطي **Create repository**.
6. اختاري **Add file → Upload files**.
7. ارفعي:
   - `Jarir_Audit_Simulation_2025.xlsx`
   - `Jarir_Audit_Simulation_2025_Report.docx`
   - `README.md`
   - `INTERVIEW_GUIDE_AR.md`
8. اكتبي رسالة التعديل:
   `Add Jarir audit simulation working papers and report`
9. اضغطي **Commit changes**.

لا ترفعي ملفات التقارير السنوية التي تم تنزيلها إلى المشروع إذا لم تكن لديكِ صلاحية لإعادة توزيعها. يكفي وضع الروابط الرسمية في README.

### الطريقة باستخدام Git

```bash
git clone https://github.com/YOUR-USERNAME/jarir-audit-simulation-2025.git
cd jarir-audit-simulation-2025

# ضعي الملفات الأربعة داخل المجلد ثم نفذي:
git add README.md INTERVIEW_GUIDE_AR.md Jarir_Audit_Simulation_2025.xlsx Jarir_Audit_Simulation_2025_Report.docx
git commit -m "Add Jarir audit simulation working papers and report"
git push origin main
```

إذا طلب GitHub تسجيل الدخول، استخدمي GitHub Desktop أو Personal Access Token. لا تضعي كلمة المرور أو token داخل README أو داخل المحادثة.

## 12. أسئلة متوقعة وإجابات قصيرة

### What is the difference between a risk and a finding?

> “A risk is a potential exposure identified during planning. A finding is an issue observed in the documented testing. In this project, both the risks and findings are clearly labeled as educational or illustrative where appropriate.”

### Why did you not issue an audit opinion?

> “Because I did not have sufficient appropriate audit evidence or access to Jarir’s internal records. The project is an educational simulation, not an audit engagement.”

### Why is missing evidence not automatically a misstatement?

> “Because missing evidence means the conclusion is unresolved. Additional evidence may demonstrate that the recorded amount is correct.”

### Why are the sample transactions fictional?

> “Public annual reports provide totals and policies, not invoice-level records. I used fictional records to demonstrate the testing logic without misrepresenting confidential or unavailable company data.”

### What would you improve next?

> “I would add actual population data if authorized, document the sampling basis in more detail, perform aggregation of identified differences, and expand cut-off and inventory count procedures.”
